#include <iostream>

int main() {
	int c = 1;
	do {
		printf("%d\n", c++);
	} while (c <= 10);
	return 0;
}

