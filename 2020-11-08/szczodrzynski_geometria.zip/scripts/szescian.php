<?php
	function szescian_pole($a) {
		return 6*pow($a, 2);
	}

	function szescian_objetosc($a) {
		return pow($a, 3);
	}

	function szescian_przekatna($a) {
		return $a*sqrt(3);
	}

	function szescian_pr_wpisanej($a) {
		return $a/2;
	}

	function szescian_pr_opisanej($a) {
		return szescian_przekatna($a)/2;
	}

