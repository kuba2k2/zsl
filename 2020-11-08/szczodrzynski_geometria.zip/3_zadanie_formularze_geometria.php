<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<table border="1">
		<tr>
			<th colspan="2">Graniastosłupy</th>
		</tr>
		<tr>
			<td><a href="prostopadloscian.php"><img src="prostopadloscian.png"></a></td>
			<td><a href="szescian.php"><img src="szescian.png"></a></td>
		</tr>
		<tr>
			<td><a href="ostroslup.php"><img src="ostroslup.png"></a></td>
			<td><a href="walec.php"><img src="walec.png"></a></td>
		</tr>
	</table>
</body>
</html>

